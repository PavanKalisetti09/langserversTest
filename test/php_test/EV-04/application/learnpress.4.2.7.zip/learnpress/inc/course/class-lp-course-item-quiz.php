<?php
class LP_Course_Item_Quiz extends LP_Course_Item {
	public $name;
	function __construct( $name ) {
		$this->name = $name;
	}
}
