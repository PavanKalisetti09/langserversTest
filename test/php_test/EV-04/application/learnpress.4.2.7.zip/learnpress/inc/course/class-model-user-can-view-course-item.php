<?php
/**
 * Class Model_Can_View_Course_Item
 *
 * @package learnpress
 */

defined( 'ABSPATH' ) || exit();

class LP_Model_User_Can_View_Course_Item {
	public $flag    = false;
	public $key     = '';
	public $message = '';

	public function __construct() {
	}
}
